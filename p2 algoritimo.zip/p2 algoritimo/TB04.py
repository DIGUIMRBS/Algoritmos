str = "infelizmente meus amigos trocaram dungeons and dragons, por pathfinder"

ltr = "i"

cntr = 0

for letra in str:
    if letra == ltr:
        cntr += 1
print(str)        
print("A letra,", ltr, "apareceu", cntr, "vezes")