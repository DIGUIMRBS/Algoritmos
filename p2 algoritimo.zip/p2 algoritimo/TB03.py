str = 'valorant e o melhor jogo de tiro ja criado'

nova_str = str.replace('valorant', 'CS:GO')

print(nova_str)

print(str,", essa era a frase original")