str = "o split e como se fosse um separador de strings, que as divide em substrings ficando tudo separado assim"

spllit = str.split()

for frs in spllit:
    print(frs)
