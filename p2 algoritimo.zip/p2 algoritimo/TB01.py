str1 = 'hellow word,'
str2 = 'olá mundo'

str = str1 + ' ' + str2

print(str)