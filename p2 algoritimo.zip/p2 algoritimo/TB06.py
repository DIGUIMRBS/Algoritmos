str = "inconstitucionalissimamente novamente? sim sim."

dgts = len(str)


print("A frase,", str, "tem", dgts, "digitos")