str = 'inconstitucionalissimamente'

for ltr in str:
    print(ltr)