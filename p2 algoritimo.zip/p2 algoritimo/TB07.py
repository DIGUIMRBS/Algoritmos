str = "eu iria colocar inconstitucionalissimamente novamente, mas acho que ela deixaria a frase muito grande então não devo usar inconstitucionalissimamente novamente"

plvr = "novamente"

ocor = str.count(plvr)

print("a palavra ",plvr,"aparece,", ocor, "vezes na frase,", str )