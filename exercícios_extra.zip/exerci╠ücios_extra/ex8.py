var = int(input("entre c um valor"))
# var = 10
# % mod é o resto da divisao
if var%2 == 0:
    print("par")
else:
    print("impar")
        
