# algoritmo
#     inteiro n, i
#     n <- 100
#     i <- 1
#     enquanto i <= n faca
#         escreva(i)
#         i <- i + 1
#     fim_enquanto
# fim_algoritmo
# =(atribuicao) e diferente de ==(igualdade)

n = 100
i = 1
while i <= n:
    print(i)
    i = i+1

