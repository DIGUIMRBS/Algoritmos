item = " "
lista=[]

def quick(array, left, right):
    if left < right:
        partition_pos = partition(array, left, right)
        quick(array, left, partition_pos - 1)
        quick(array, partition_pos + 1, right)

def partition(array, left, right):
    i = left
    j = right - 1
    pivot = array[right]

    while i < j:
        while i < right and array[i] < pivot:
            i += 1
        while j > left and array[j] >= pivot:
            j -= 1
        if i < j:
            array[i], array[j] = array[j], array[i]

    if array[i] > pivot:
        array[i], array[right] = array[right], array[i]
    return i


while item != "":
    item = input('Insira um numero ou aperte enter para encerrar: ')
    if item != "":
        lista.append(int(item))

quick(lista, 0, len(lista) - 1)
print(lista)