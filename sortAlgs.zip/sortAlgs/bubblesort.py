item = " "
lista=[]

def bubble(array):
    for final in range(len(array), 0, -1):
        exchanging = False
        for current in range(0, final-1):
            if array[current] > array[current+1]:
                array[current], array[current+1] = array[current+1], array[current]
                exchanging = True
        if not exchanging:
            break

while item != "":
    item = input('Insira um numero ou aperte enter para encerrar: ')
    if item != "":
        lista.append(int(item))

bubble(lista)
print(lista)