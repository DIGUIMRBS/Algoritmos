item = " "
lista=[]

def insert(array):
    for index in range(0, len(array)):
        current = array[index]
        while index > 0 and array[index-1] > current:
            array[index] = array[index-1]
            index -= 1
        array[index] = current   

while item != "":
    item = input('Insira um numero ou aperte enter para encerrar: ')
    if item != "":
        lista.append(int(item))

insert(lista)
print(lista)