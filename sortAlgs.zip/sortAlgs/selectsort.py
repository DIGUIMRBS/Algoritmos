item = " "
lista=[]

def select(array):
    for index in range(0, len(array)):
        min_index = index

        for right in range(index + 1, len(array)):
            if array[right] < array[min_index]:
                min_index = right
        
        array[index], array[min_index] = array[min_index], array[index]

while item != "":
    item = input('Insira um numero ou aperte enter para encerrar: ')
    if item != "":
        lista.append(int(item))

select(lista)
print(lista)