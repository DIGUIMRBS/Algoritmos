def padrao(n):
    for i in range(1, n + 1):
        linha = ""
        for j in range(1, i + 1):
            linha += str(j) + " "
        print("o         ", linha)

n = int(input("Digite o numero n que você deseja: "))
padrao(n)