def argumentos(a, b, c):
    soma = a + b + c
    return soma
resultado = argumentos(7, 49, 12)
print(resultado)