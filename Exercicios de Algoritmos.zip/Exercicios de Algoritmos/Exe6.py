def converter(horas, minutos):
    if horas >= 0 and horas <= 23 and minutos >= 0 and minutos <= 59:
        if horas == 0:
            horas12 = 12
            periodo = 'A.M.'
        elif horas < 12:
            horas12 = horas
            periodo = 'A.M.'
        elif horas == 12:
            horas12 = 12
            periodo = 'P.M.'
        else:
            horas12 = horas - 12
            periodo = 'P.M.'
            
        return horas12, minutos, periodo
    else:
        return None

def notacao(horas12, minutos, periodo):
    print(f"A notação de 12 horas é: {horas12}:{minutos:02d} {periodo}")

while True:
    horas = int(input("Digite as horas (0-23): "))
    minutos = int(input("Digite os minutos (0-59): "))
    
    resultado = converter(horas, minutos)
    
    if resultado is not None:
        horas12, minutos, periodo = resultado
        notacao(horas12, minutos, periodo)
    else:
        print("Os valoreres inseridos podem estar errados. Tente novamente.")
    
    opcao = input("Você quer converter outros horarios? (S/N): ")
    if opcao.lower() != 's':
        break