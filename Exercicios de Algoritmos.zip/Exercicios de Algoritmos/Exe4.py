def programa(numero):
    if numero > 0:
        return 'P'
    else:
        return 'N'

valor = int(input("Digite um número: "))
resultado = programa(valor)
print("A resposta é:", resultado)