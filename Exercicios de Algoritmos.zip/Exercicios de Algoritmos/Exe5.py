def imposto(taxaImposto, custo):
    custo += custo * taxaImposto / 100
    return custo

item = 100 
taxa = 10 

valor = imposto(taxa, item)
print("Valor do item depois dos impostos: R$", valor)