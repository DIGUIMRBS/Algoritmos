def num(n):
    for i in range(1, n+1):
        linha = 'o          '
        for j in range(i):
            linha += str(i) + ' '
        print(linha)

n = int(input('Digite o numero que voce quer: '))
num(n)
