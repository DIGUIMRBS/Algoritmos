string = 'Paralelepipedo'

for ltr in string:
    print(ltr)