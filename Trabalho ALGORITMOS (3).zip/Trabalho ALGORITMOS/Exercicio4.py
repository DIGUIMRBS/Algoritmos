string = "Porque eu tenho que trabalhar em dois lugares diferentes?"

ltr = "a"

ctdr = 0

for letra in string:
    if letra == ltr:
        ctdr += 1
print(string)        
print("A letra,", ltr, "apareceu", ctdr, "vezes")