string = "Uma rua de paralelepipedos em Saquarema."

Digi = len(string)


print("A frase a seguir,", string, "tem", Digi, "digitos")