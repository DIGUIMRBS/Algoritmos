string1 = 'Hellow Word,'
string2 = 'Olá Mundo'

string = string1 + ' ' + string2

print(string)