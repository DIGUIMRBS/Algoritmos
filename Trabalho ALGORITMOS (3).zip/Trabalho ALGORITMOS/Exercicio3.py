string = 'Forza Horizon é o melhor jogo de corrida de mundo livre já criado'

novastring = string.replace('Forza Horizon', 'NFS')

print(novastring)

print(string,", essa era a frase original")