string = " o termo “split” é usado para dividir uma string em pequenos pedaços, que as divide em substrings"

spllit = string.split()

for frs in spllit:
    print(frs)
