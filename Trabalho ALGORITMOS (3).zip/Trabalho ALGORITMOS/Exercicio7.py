string = "tão certo, tão bomito, tão lindo, o infinito, tão grande que não acaba tão cedo"

palavra = "tão"

vezes = string.count(palavra)

print("a palavra ",palavra,"aparece,", vezes, "vezes na frase,", string )